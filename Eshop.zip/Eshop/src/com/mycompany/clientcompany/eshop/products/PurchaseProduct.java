package com.mycompany.clientcompany.eshop.products;

import java.sql.SQLException;
import java.util.Scanner;

import com.mycompany.clientcompany.eshop.admin.AdminLogin;
import com.mycompany.clientcompany.eshop.user.inputvalidation.UserInputValidation;
import com.mycompany.clientcompany.eshop.user.login.UserLogin;
import com.mycompany.clientcompany.eshop.user.registration.UserRegistration;

public class PurchaseProduct extends UserInputValidation {

	public void buyProduct() throws SQLException {

		Scanner scanner = new Scanner(System.in);

		System.out.println("Below is our product list feel free to buy a product.....");
		System.out.println();
		System.out.println(
				"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

		ProductList productList = new ProductList();

		productList.printProduct();

		System.out.println(
				"*************************************************************************************************************************************************************************");
		System.out.println();
		System.out.println("1. If you want to continue shopping please press 1");
		System.out.println("2. If you want to see your cart please press 2");
		System.out.println("3. If you want to exit press 3");
		System.out.println();
		System.out.println(
				"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

		System.out.println();

		// taking correct input
		int buyCart = super.correctInput(3);

		boolean isShopping= true;
		
		while(isShopping) {
			
			isShopping = false;
			
			if (buyCart == 1) {

				System.out.println(
						"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

				System.out.println();

				AddToCart addToCart = new AddToCart();

				addToCart.addProduct(buyCart);

			} else if (buyCart == 2) {

				Cart cart = new Cart();

				cart.getCart();

				System.out.println();

				
					System.out.println("1. If you want to continue shopping please press 1");
					System.out.println("2. If you want to exit press 2");

					System.out.println();
					System.out.println(
							"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
					System.out.println();
					
					int afterCartCheck = super.correctInput(2);

					if (afterCartCheck == 1) {
						
						isShopping = true;
						buyCart = 1;

					} else if (afterCartCheck == 2) {

						
						System.out.println(
								".............................Thank you for visiting us.......................................");
					}

			} else if (buyCart == 3) {

				System.out.println(
						".............................Thank you for visiting us.......................................");

			}
			
		}

	}

	public static void main(String[] args) {

		PurchaseProduct purchaseProduct = new PurchaseProduct();

		try {
			purchaseProduct.buyProduct();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

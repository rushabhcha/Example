package com.mycompany.clientcompany.eshop.products;

import java.sql.SQLException;
import java.util.Map;
import java.util.Set;

import com.mycompany.clientcompany.eshop.database.ProductData;

public class ProductList {
	
	//method to print product list
	public void printProduct() throws SQLException {
		ProductData productData= new ProductData();
		
		Map<Integer, Map<String, Object>> allProducts = productData.getAllProducts();
		
		Set<Integer> keySet = allProducts.keySet();
		
		System.out.println();
		System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
		System.out.println();
		
		for(Integer k: keySet) {
			Map<String, Object> singleProduct = allProducts.get(k);
			
			System.out.println(k + "   ||   Name: " +singleProduct.get("productName") + "   ||   Details: " + singleProduct.get("productDescription")
			
					+ "   ||   Price: "+ singleProduct.get("productPrice")+ "   ||   Quantity: " + singleProduct.get("producQuantity"));
		
			System.out.println();
			System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
//			System.out.println("=================================================================================================================================");
			System.out.println();
		}
	}

	public static void main(String[] args) throws SQLException {

		ProductList productList = new ProductList();
		
		productList.printProduct();
	}

}

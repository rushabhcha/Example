package com.mycompany.clientcompany.eshop.products;

import java.sql.SQLException;
import java.util.Map;
import java.util.Set;

import com.mycompany.clientcompany.eshop.database.ProductData;

public class AmountCalculations {
	
	//method to calculate the amount of products which is in cart
	public double getAmount(Set<Integer> productIdList) throws SQLException {
		
		double amount=0.0;
		
		ProductData productData = new ProductData();
		
		Map<Integer, Map<String, Object>> allProducts = productData.getAllProducts();
		
		Set<Integer> allProductKeys = allProducts.keySet();
		
		
		for (Integer productId : productIdList) {

			for (Integer productKey : allProductKeys) {

				Map<String, Object> singleProduct = allProducts.get(productKey);

				Object object = singleProduct.get("productPrice");

				// changing data type from Object to double
				double productPrice = (double) object;

				if (productId == productKey) {

					amount += productPrice;

				}

			}

		}
		
		return amount;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

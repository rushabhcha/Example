package com.mycompany.clientcompany.eshop.products;

import java.sql.SQLException;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.mycompany.clientcompany.eshop.database.ProductData;
import com.mycompany.clientcompany.eshop.user.inputvalidation.UserInputValidation;

public class Cart extends UserInputValidation {

	// method to get the cart and amount
	public boolean getCart(Set<Integer> productIdList) throws SQLException {

		Scanner scanner = new Scanner(System.in);

		// variable required if we want to continue shopping
		boolean isShopping = false;

		// to know the number of products in in our cart
		int numberOfProducts = productIdList.size();

		// get all product data
		ProductData productData = new ProductData();
		Map<Integer, Map<String, Object>> allProducts = productData.getAllProducts();

		// getting all keyset of hashMap
		Set<Integer> allProductKeys = allProducts.keySet();

		// to calculate the amount
		double amount = 0.0;

		// if there is product in our cart then calculate the amount
		if (numberOfProducts > 0) {

			// calling the method to calculate the amount
			AmountCalculations amountCalculations = new AmountCalculations();

			amount = amountCalculations.getAmount(productIdList);

		}

		System.out.println();
		System.out.println(
				"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
		System.out.println();

		System.out.println("Number of items in your cart = " + numberOfProducts
				+ "            Total amount you have to pay= " + amount);

		System.out.println();
		System.out.println(
				"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

		// if number of products greater than 0 then only we have to check cart details
		if (numberOfProducts > 0) {

			System.out.println();
			System.out.println("1. If you want to see cart details please press 1");
			System.out.println("2. If you want place the order please press 2");
			System.out.println("3. If you want to countinue Shopping please press 3");
			System.out.println("4. If you want to exit then press 4");

			System.out.println();
			System.out.println(
					"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
			System.out.println();

			int checkBuy = super.correctInput(4);

			// to get our cart details
			if (checkBuy == 1) {

				System.out.println(
						"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
				System.out.println();
				
				System.out.println("Below is the cart details...");
				System.out.println(".......................................................");

				System.out.println();
				
				for (Integer productId : productIdList) {

					for (Integer productKey : allProductKeys) {

						Map<String, Object> singleProduct = allProducts.get(productKey);

						Object object = singleProduct.get("productPrice");

						// changing data type from Object to double
						double productPrice = (double) object;

						if (productId == productKey) {

							System.out.println("Porduct Id: " + productId);
							System.out.println("Porduct Name: " + singleProduct.get("productName"));
							System.out.println("Porduct Details: " + singleProduct.get("productDescription"));
							System.out.println("Porduct Price: " + singleProduct.get("productPrice"));
							System.out.println("Porduct Quantity Available: " + singleProduct.get("producQuantity"));
							System.out
									.println("=======================================================================");
							System.out.println();
						}
					}
				}

				System.out.println(
						"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
				System.out.println();

				System.out.println("1. If you want place the order please press 1");
				System.out.println("2. If you want to countinue Shopping please press 2");
				System.out.println("3. If you want to exit then press 3");

				System.out.println();
				System.out.println(
						"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
				System.out.println();

				int checkBuy2 = super.correctInput(3);

				if (checkBuy2 == 1) {

					// calling method to place order
					PlaceOrder placeOrder = new PlaceOrder();
					boolean isOrderPlace = placeOrder.saveOrder(productIdList);

					if (isOrderPlace) {
						System.out.println();
						System.out.println(
								"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

						System.out.println("Your order placed successfully ! .........");

						System.out.println();
						System.out.println(
								"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

						System.out.println();
						System.out.println("1. to contune shopping press 1");
						System.out.println("2. to exit press 2");
						System.out.println();
						System.out.println(
								"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
						System.out.println();
						
						int afterOrder = super.correctInput(2);
						
						if(afterOrder == 1) {
							
							
							//as we want to empty cart before buying the product.....
							//if we call method then first our cart will be empty ......
							AddToCart addToCart = new AddToCart();
							addToCart.addProduct(1);
						}else if(afterOrder == 2) {
							
							isShopping = false;
						}
						
					} else {

						System.out.println();
						System.out.println(
								"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

						super.throwOrderException();

						System.out.println();
						System.out.println(
								"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

						isShopping = true; // as we want to continue shopping

					}

				} else if (checkBuy2 == 2) {

					isShopping = true; // as we want to continue shopping
				} else if (checkBuy2 == 3) {
					System.out.println();

					isShopping = false;
				}

			} else if (checkBuy == 2) {

				// calling method to place order
				PlaceOrder placeOrder = new PlaceOrder();
				boolean isOrderPlace = placeOrder.saveOrder(productIdList);

				if (isOrderPlace) {
					System.out.println();
					System.out.println(
							"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
					System.out.println();
					System.out.println("Your order placed successfully ! .........");

					System.out.println();
					System.out.println(
							"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
					System.out.println();
					System.out.println("1. to contune shopping press 1");
					System.out.println("2. to exit press 2");
					System.out.println();
					System.out.println(
							"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
					System.out.println();
					
					int afterOrder = super.correctInput(2);
					
					if(afterOrder == 1) {
						
						
						//as we want to empty cart before buying the product.....
						//if we call method then first our cart will be empty ......
						AddToCart addToCart = new AddToCart();
						addToCart.addProduct(1);
					}else if(afterOrder == 2) {
						
						isShopping = false;
					}
					

					
					
				} else {

					System.out.println();
					System.out.println(
							"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

					super.throwOrderException();

					System.out.println();
					System.out.println(
							"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

					isShopping = true; // as we want to continue shopping

				}

			} else if (checkBuy == 3) {

				isShopping = true; // as we want to continue shopping

			} else if (checkBuy == 4) {

				System.out.println();

				isShopping = false;
			}

		}

		return isShopping;

	}

	// overloading getCart method
	public void getCart() throws SQLException {
		Set<Integer> emptyProductList = new LinkedHashSet<>();
		this.getCart(emptyProductList);

	}

	public static void main(String[] args) {
		Cart cart = new Cart();
		try {
			cart.getCart();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

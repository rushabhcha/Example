package com.mycompany.clientcompany.eshop.products;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import com.mycompany.clientcompany.eshop.database.InsertOrderDatabase;
import com.mycompany.clientcompany.eshop.database.UserData;

public class PlaceOrder {

	
	public boolean saveOrder(Set<Integer> productIdList) throws SQLException {
		
		//Requirement .....................
		//1. customer_id
		//2. order date
		//3. amount
		
		boolean isOrderPlace=false;
		
		//get the customer id
		Integer customerId=null;
		String userName= null;
		String password = null;
		
		//to get user Id we will use properties file data
		try {
		
			FileInputStream fileInputStream = new FileInputStream("D:\\Programing\\Velocity Classes\\MiniProject\\code\\Eshop\\src\\com\\mycompany\\clientcompany\\eshop\\user\\login\\frequentlyChangeData.properties");
		
			Properties properties = new Properties();
			
			properties.load(fileInputStream);
			
			userName = properties.getProperty("userName");
			password = properties.getProperty("password");
			
			//System.out.println(userName);
			//System.out.println(password);
			
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		
		} catch (IOException e) {

			e.printStackTrace();
			
		}
		
		//as we know the userName and password so find out the id of user
		
		UserData userData = new UserData();
		Map<Integer, Map<String, String>> allUsersData = userData.getUserData();
		
		Set<Integer> usersKeys = allUsersData.keySet();
		
		for(Integer userKey : usersKeys) {
			
			Map<String, String> singleUserData = allUsersData.get(userKey);
			
			String singleUserName = singleUserData.get("firstName");
			String singleUserPassword = singleUserData.get("password");
			
			if(userName.equals(singleUserName) && password.equals(singleUserPassword)) {
				customerId = userKey;
//				System.out.println("customer id Set: "+ customerId);
			}
			
		}
		
		
		//calculate the amount of our product
		//calling the method to calculate the amount
		
		AmountCalculations amountCalculations = new AmountCalculations();
		
		double amount = amountCalculations.getAmount(productIdList);
		
		
		//inserting order into database
		
		//calling method to insert our order into database
		InsertOrderDatabase insertOrderDatabase = new InsertOrderDatabase();
		
		if(customerId != null) {
			
			isOrderPlace = insertOrderDatabase.insertOrder(customerId, amount);
			
		}else {
			System.out.println(customerId);
		}
		
		return isOrderPlace;
	}

	public static void main(String[] args) throws SQLException {
		
		Set<Integer> lhs= new LinkedHashSet<>();
		
		lhs.add(1);
		lhs.add(9);
		
		PlaceOrder placeOrder = new PlaceOrder();
		placeOrder.saveOrder(lhs);
		
//		

	}

}

package com.mycompany.clientcompany.eshop.products;

import java.sql.SQLException;
import java.util.Scanner;

import com.mycompany.clientcompany.eshop.admin.AdminFunctionality;
import com.mycompany.clientcompany.eshop.admin.AdminLogin;
import com.mycompany.clientcompany.eshop.user.inputvalidation.UserInputValidation;
import com.mycompany.clientcompany.eshop.user.login.UserLogin;
import com.mycompany.clientcompany.eshop.user.registration.UserRegistration;

public class MainClass extends UserInputValidation{
	
	//method to execute all program
	public void eShop() throws SQLException {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println();

		System.out.println(
				"                                      ......Welcome to E-Shop.....                                       ");

		System.out.println();
		System.out.println(
				"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
		
			System.out.println();
			System.out.println("1. For admin login please press 1");
			System.out.println("2. For user Login press 2");
			System.out.println("3. For user registration press 3");
			System.out.println("4. For exit press 4");
			System.out.println();
			System.out.println(
					"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
			System.out.println();

			//calling method of supercalss for correct input
			
			int userCheck = super.correctInput(4);
			
			if(userCheck == 1) {
				
				//creating the object of AdminLogin class
				AdminLogin adminLogin= new AdminLogin();
				
				//calling method
				adminLogin.loginAdmin();
				System.out.println();
				System.out.println("Wecome admin: Java Z2 Group......");
				
				System.out.println("------------------------------------");

				AdminFunctionality adminFunctionality = new AdminFunctionality();
				adminFunctionality.adminsWork();
				
			}else if (userCheck == 2) {

				UserLogin userLogin = new UserLogin();
				userLogin.loginUser();

			} else if (userCheck == 3) {


				UserRegistration userRegistration = new UserRegistration();
				userRegistration.insertUser();

			} else if(userCheck == 4){
				
				System.out.println(
						".............................................Thank you for visiting us...........................................................");

			
		}
		
	}

	public static void main(String[] args){
		MainClass mainClass = new MainClass();
		
		try {
			mainClass.eShop();
			
		} catch (SQLException e) {


			e.printStackTrace();
		}
		

	}

}

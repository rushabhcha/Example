package com.mycompany.clientcompany.eshop.products;

import java.sql.SQLException;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;

import com.mycompany.clientcompany.eshop.user.inputvalidation.UserInputValidation;

public class AddToCart extends UserInputValidation {

	// method to add the product into cart
	public void addProduct(int buyCart) throws SQLException {
		Set<Integer> productIdList = new LinkedHashSet<>();

		Scanner scanner = new Scanner(System.in);

		while (buyCart == 1) {

			System.out.println(
					"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

			System.out.println();
//			System.out.println("Please enter the product id to add into cart......");
//			
//			System.out.println();
//			System.out.println(
//					"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
//			
			int addCart = super.correctProductId(10);
			System.out.println();
			System.out.println(
					"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

			if (addCart > 0 && addCart <= 10) {

				// adding product in in Set object
				productIdList.add(addCart);

				System.out.println();
				// giving massage for product added successfully
				System.out.println("product with Id " + addCart + " successfully add into cart.....");

				System.out.println();

				// to restrict user to enter any random value

				System.out.println(
						"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
				System.out.println();
				System.out.println("1. If you want to continue Shopping then press 1");
				System.out.println("2. If you want to see your cart then press 2");
				System.out.println("3. If you want to exit then press 3");
				System.out.println();

				System.out.println(
						"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
				System.out.println();
				int tempNum = super.correctInput(3);

				// if we have to continue shopping
				if (tempNum == 1) {

					buyCart = 1;

				} else if (tempNum == 2) { // if we want to see cart

					Cart cart = new Cart();

					// if method returns true that means user want to continue shopping after seeing
					// the cart
					boolean isShopping = cart.getCart(productIdList);

					if (isShopping) {

						buyCart = 1;

					} else {
						System.out.println(
								"...................................................................Thank you for visiting us !..........................................................");

						// to exit give any value other than 1
						buyCart = 3;
					}

				} else if (tempNum == 3) { // for exit

					System.out.println(
							"...................................................................Thank you for visiting us !..........................................................");
					buyCart = 3;

				}
			}
		}

	}

	public static void main(String[] args) {
		AddToCart addToCart = new AddToCart();

		try {
			addToCart.addProduct(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

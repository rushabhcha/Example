package com.mycompany.clientcompany.eshop.user.registration;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import com.mycompany.clientcompany.eshop.user.login.UserLogin;

public class UserRegistration {

	// method to save user details in database
	public void insertUser() throws SQLException {

		// creating the object of scanner class to take input from user
		Scanner scanner = new Scanner(System.in);

		System.out.println("Enter the first name: ");
		String firstName = scanner.next();

		System.out.println("Enter the last name: ");
		String lastName = scanner.next();

		System.out.println("Enter the password: ");
		String password = scanner.next();

		System.out.println("Enter the email address: ");
		String email = scanner.next();

		// saving this data into database

		Connection connection = null;
		PreparedStatement prepareStatement = null;
		try {

			Class.forName("com.mysql.cj.jdbc.Driver");

			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/e_shop", "root", "root");

			prepareStatement = connection
					.prepareStatement("insert into user(user_fname, user_lname, user_password, email)values(?,?,?,?)");

			prepareStatement.setString(1, firstName);
			prepareStatement.setString(2, lastName);
			prepareStatement.setString(3, password);
			prepareStatement.setString(4, email);

			int i = prepareStatement.executeUpdate();

			System.out.println("User is registered !");
			System.out.println();
			System.out.println("----------------------------------------------------------------------");
			System.out.println();
			
			boolean checkLoginInput= true;
			
			while(checkLoginInput) {
				
				System.out.println("1. If you want to login press 1");
				System.out.println("2. If you want to exit press 2");
				int checkLogin = scanner.nextInt();
				
				checkLoginInput= false;
				if (checkLogin == 1) {
					UserLogin userLogin = new UserLogin();
					
					userLogin.loginUser();
					
				}else if(checkLogin == 2){
					System.out.println("...................... Thank you for registration please visit again ! .............................");
				}else {
					
					System.out.println(" please choose option from 1,2 ......................");
					
					checkLoginInput=true;
				}
				
				
			}
			
	

		} catch (ClassNotFoundException e) {

			e.printStackTrace();

		} catch (SQLException e) {

			e.printStackTrace();

		} finally {

			connection.close();
			prepareStatement.close();
			scanner.close();

		}

	}

	public static void main(String[] args) throws SQLException {
		UserRegistration userRegistration = new UserRegistration();
		userRegistration.insertUser();
	}

}

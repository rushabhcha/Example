package com.mycompany.clientcompany.eshop.user.inputvalidation;

public class UserInputException extends RuntimeException{
	
	public UserInputException(String msg) {
		
		super(msg);
		
	}

}

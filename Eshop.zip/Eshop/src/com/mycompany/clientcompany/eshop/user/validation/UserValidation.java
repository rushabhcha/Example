package com.mycompany.clientcompany.eshop.user.validation;

public class UserValidation {
	
	//method to validate user
	public void validateUser() {
		
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

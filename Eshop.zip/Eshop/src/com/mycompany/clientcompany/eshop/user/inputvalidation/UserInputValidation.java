package com.mycompany.clientcompany.eshop.user.inputvalidation;

import java.util.Scanner;

public class UserInputValidation {
	
	//method to correct the input
	public int correctInput(int numberOfOption) {

		Scanner scanner = new Scanner(System.in);

		int userInput = 0;

		boolean checkInput = true;
		

		System.out.println("please enter the value between 1 to " + numberOfOption+ " .......");
		System.out.println();

		while (checkInput)

			try {

				try {

					userInput = scanner.nextInt();

				} catch (Exception e) {

					scanner.nextLine();
					throw new UserInputException("please enter integer value........");
				}

				if (userInput > numberOfOption || userInput == 0) {
					throw new UserInputException(
							"pleas enter value between 1 to " + numberOfOption + " ...................");
				}

				checkInput = false;

			} catch (Exception e) {
				
				System.out.println();
				System.out.println(
						"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
				System.out.println();
				
				try {
					
					Thread.currentThread().sleep(20);
					
				} catch (InterruptedException e1) {

					e1.printStackTrace();
					
				}
				
				e.printStackTrace();

				try {
					
					Thread.currentThread().sleep(20);
					
				} catch (InterruptedException e2) {

					e2.printStackTrace();
					
				}
				
				checkInput = true;
				

				System.out.println();
				System.out.println(
						"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
				System.out.println();
				System.out.println("please enter the value between 1 to " + numberOfOption+ " .......");
				System.out.println();

			}

		return userInput;

	}
	
	
	//method to throw when login inputs are wrong
	public void throwLoginException() {
		
		try {
			throw new UserInputException("userName and password does not match................");
		} catch (Exception e) {
			e.printStackTrace();
			
			try {
				
				Thread.currentThread().sleep(20);
				
			} catch (InterruptedException e1) {

				e1.printStackTrace();
			}
		}
	}
	
	//method to correct product id
	
	public int correctProductId(int numberOfProduct) {
		
		
		System.out.println("Please enter the product id: ");

		System.out.println();
		int userInput=this.correctInput(numberOfProduct);
		
		return userInput;
	}
	
	
	//method to get correct user id
	
	public int correctUserId(int numberOfUsers) {
		
		System.out.println("Enter the user id below:");
		System.out.println();
		int userInput = this.correctInput(numberOfUsers);
		
		return userInput;
	}
	
	
	//method to throw exception when order is not placed
	public void throwOrderException() {
		
		try {
			throw new UserInputException("Order is not placed ! ................");
		} catch (Exception e) {
			e.printStackTrace();
			
			try {
				
				Thread.currentThread().sleep(20);
				
			} catch (InterruptedException e1) {

				e1.printStackTrace();
			}
		}
	}
	
	
	public static void main(String[] args) {
		UserInputValidation userInputValidation = new UserInputValidation();
		int userInput = userInputValidation.correctInput(4);
	}

}

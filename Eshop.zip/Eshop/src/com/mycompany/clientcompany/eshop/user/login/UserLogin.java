package com.mycompany.clientcompany.eshop.user.login;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.mycompany.clientcompany.eshop.database.UserData;
import com.mycompany.clientcompany.eshop.products.PurchaseProduct;
import com.mycompany.clientcompany.eshop.user.inputvalidation.UserInputValidation;
import com.mycompany.clientcompany.eshop.user.registration.UserRegistration;

public class UserLogin extends UserInputValidation {

	public void loginUser() throws SQLException {
		Scanner scanner = new Scanner(System.in);
		System.out.println();
		System.out.println("Please Login........");
		System.out.println();
		System.out.println("Enter the user name: ");
		String userName = scanner.next();
		System.out.println("Enter the password: ");
		String password = scanner.next();

		UserData userData = new UserData();

		Map<Integer, Map<String, String>> allUserData = userData.getUserData();

		Set<Integer> keySet = allUserData.keySet();

		boolean userFound = false;
		String lastName = null;

		for (Integer k : keySet) {

			Map<String, String> singleUser = allUserData.get(k);

			String singleUserFirstName = singleUser.get("firstName");

			String singleUserPassword = singleUser.get("password");

			if (userName.equals(singleUserFirstName) && password.equals(singleUserPassword)) {
				userFound = true;
				lastName = singleUser.get("lastName");
			}
		}

		if (userFound) {

			// if user found the we can store its data in .properties file so we cause
			// latter
			FileWriter fileWriter = null;
			try {

				fileWriter = new FileWriter(
						"D:\\Programing\\Velocity Classes\\MiniProject\\code\\Eshop\\src\\com\\mycompany\\clientcompany\\eshop\\user\\login\\frequentlyChangeData.properties");

				fileWriter.write("userName=" + userName + "\npassword=" + password);

			} catch (IOException e) {

				e.printStackTrace();

			} finally {
				try {

					fileWriter.close();

				} catch (IOException e) {

					e.printStackTrace();
				}
			}

			System.out.println();
			System.out.println(
					"*********************************************************************************************************************");
			System.out.println();
			System.out.println("Welcome Mr / Miss: " + userName + " " + lastName);
			System.out.println();

			// if user is verified then go for shopping
			PurchaseProduct purchaseProduct = new PurchaseProduct();
			purchaseProduct.buyProduct();

		} else {


			// As login fail throwing exception

			System.out.println();
			System.out.println(
					"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

			System.out.println();

			super.throwLoginException();

			System.out.println();
			System.out.println(
					"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

			System.out.println();

			System.out.println("1. to login again press 1");
			System.out.println("2. for new user registration press 2");
			System.out.println("3. to exit press 3");
			
			
			System.out.println();
			System.out.println(
					"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

			System.out.println();
			
			int checkPoint = super.correctInput(3);

			if (checkPoint == 1) {

				this.loginUser();

			} else if (checkPoint == 2) {

				UserRegistration userRegistration = new UserRegistration();

				userRegistration.insertUser();

			} else if(checkPoint == 3) {
				
				System.out.println(".............................Thank you for visiting us ! ...................................");
			}

		}

	}

	public static void main(String[] args) {
		UserLogin userLogin = new UserLogin();

		try {
			userLogin.loginUser();

		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

}

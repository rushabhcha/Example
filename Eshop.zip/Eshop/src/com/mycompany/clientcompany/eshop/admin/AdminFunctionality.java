package com.mycompany.clientcompany.eshop.admin;

import java.sql.SQLException;
import java.util.Scanner;

import com.mycompany.clientcompany.eshop.database.OrderData;
import com.mycompany.clientcompany.eshop.user.inputvalidation.UserInputValidation;

public class AdminFunctionality extends UserInputValidation{

	// method to perform admins functionality
	public void adminsWork() throws SQLException {

		Scanner scanner = new Scanner(System.in);


			System.out.println("1. to check the quantity of every product press 1");
			System.out.println("2. to check all users list press 2");
			System.out.println("3. to check purches history of user press 3");
			System.out.println("4. to exit press 4");
			System.out.println();
			System.out.println(
					"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

			int workCheck = super.correctInput(4);
			System.out.println();
			if (workCheck == 1) {

				System.out.println();
				// calling the method to calculate the product quantity

				QuantityDisplay quantityDisplay = new QuantityDisplay();

				quantityDisplay.getQuantity();

			} else if (workCheck == 2) {
				
				// calling method to get Users List	
				UsersList usersList = new UsersList();
				usersList.getUserList();
				System.out.println();
				
			} else if (workCheck == 3) {

				System.out.println();
				
				System.out.println(
						"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

				System.out.println();
				
				int orderCheck = super.correctUserId(10);
				
				System.out.println();
				System.out.println(
						"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

				System.out.println();
				System.out.println("User Purchase History.........");
				System.out.println();

				//calling method to check history of purchase
				OrderData orderData = new OrderData();
				orderData.getOrdersData(orderCheck);
					
			} else if (workCheck == 4) {

				System.out.println(
						".............................Thank you for visiting us.......................................");

			}

		

	}

	public static void main(String[] args) {

		AdminFunctionality adminFunctionality = new AdminFunctionality();

		try {
			adminFunctionality.adminsWork();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

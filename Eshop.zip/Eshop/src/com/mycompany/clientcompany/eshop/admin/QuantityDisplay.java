package com.mycompany.clientcompany.eshop.admin;

import java.sql.SQLException;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.mycompany.clientcompany.eshop.database.OrderData;
import com.mycompany.clientcompany.eshop.database.ProductData;
import com.mycompany.clientcompany.eshop.user.inputvalidation.UserInputValidation;

public class QuantityDisplay extends UserInputValidation {

	// method to display product Id name quantity

	public void getQuantity() throws SQLException {
		Scanner scanner = new Scanner(System.in);

		ProductData productData = new ProductData();

		Map<Integer, Map<String, Object>> allProducts = productData.getAllProducts();

		//calling method of superclass to get correct product Id
		
		int checkId = super.correctProductId(10);

		if (checkId > 0 && checkId <= 10) {
			System.out.println();
			// if id is in range then get the product quantity

			Map<String, Object> singleProduct = allProducts.get(checkId);
			System.out.println("Product Id = " + checkId + "		Product Name = " + singleProduct.get("productName")
					+ "		Product Quantities = " + singleProduct.get("producQuantity"));
			System.out.println();

			System.out.println(
					"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

			System.out.println();

		}
		
		//logic to continue admins work
		
		System.out.println("1. to check the quantity of every product press 1");
		System.out.println("2. to check all users list press 2");
		System.out.println("3. to check purches history of user press 3");
		System.out.println("4. to exit press 4");
		System.out.println();
		System.out.println(
				"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

		int workCheck = super.correctInput(4);
		System.out.println();
		if (workCheck == 1) {

			System.out.println();
			// calling the method to calculate the product quantity

			this.getQuantity();

		} else if (workCheck == 2) {
			
			// calling method to get Users List	
			UsersList usersList = new UsersList();
			usersList.getUserList();
			System.out.println();
			
		} else if (workCheck == 3) {

			System.out.println();
			
			System.out.println(
					"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

			System.out.println();
			
			int orderCheck = super.correctUserId(10);
			
			System.out.println();
			System.out.println(
					"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

			System.out.println();
			System.out.println("User Purchase History.........");
			System.out.println();

			//calling method to check history of purchase
			OrderData orderData = new OrderData();
			orderData.getOrdersData(orderCheck);
				
		} else if (workCheck == 4) {

			System.out.println(
					".............................Thank you for visiting us.......................................");

		}
	
		
		
	}

	public static void main(String[] args) {
		QuantityDisplay quantityDisplay = new QuantityDisplay();

		try {

			quantityDisplay.getQuantity();

		} catch (SQLException e) {
		
			e.printStackTrace();
		}

	}

}

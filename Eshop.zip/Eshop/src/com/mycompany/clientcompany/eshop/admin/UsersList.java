package com.mycompany.clientcompany.eshop.admin;

import java.sql.SQLException;
import java.util.Map;
import java.util.Set;

import com.mycompany.clientcompany.eshop.database.OrderData;
import com.mycompany.clientcompany.eshop.database.UserData;
import com.mycompany.clientcompany.eshop.user.inputvalidation.UserInputValidation;

public class UsersList extends UserInputValidation{

	// method to display all register user list

	public void getUserList() throws SQLException {
		System.out.println("Below is the list of all Registerd users: ");
		System.out.println();
		
		System.out.println("-----------------------------------------------------");

		// Getting the list of all users

		UserData userData = new UserData();
		Map<Integer, Map<String, String>> registerUsers = userData.getUserData();

		Set<Integer> usersKeys = registerUsers.keySet();

		for (Integer k : usersKeys) {
			Map<String, String> singleUser = registerUsers.get(k);
			String fullName = singleUser.get("firstName") + " " + singleUser.get("lastName");
			System.out.println();
			System.out.println("User Id: "+ k + "		User Name: "+ fullName );
			System.out.println();
			System.out.println("-----------------------------------------------------");
		}
		
		//logic to continue admins work
		System.out.println("1. to check the quantity of every product press 1");
		System.out.println("2. to check all users list press 2");
		System.out.println("3. to check purches history of user press 3");
		System.out.println("4. to exit press 4");
		System.out.println();
		System.out.println(
				"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

		int workCheck = super.correctInput(4);
		System.out.println();
		if (workCheck == 1) {

			System.out.println();
			// calling the method to calculate the product quantity

			QuantityDisplay quantityDisplay = new QuantityDisplay();

			quantityDisplay.getQuantity();

		} else if (workCheck == 2) {
			
			// calling method to get Users List	
			UsersList usersList = new UsersList();
			usersList.getUserList();
			System.out.println();
			
		} else if (workCheck == 3) {

			System.out.println();
			
			System.out.println(
					"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

			System.out.println();
			
			int orderCheck = super.correctUserId(10);
			
			System.out.println();
			System.out.println(
					"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

			System.out.println();
			System.out.println("User Purchase History.........");
			System.out.println();

			//calling method to check history of purchase
			OrderData orderData = new OrderData();
			orderData.getOrdersData(orderCheck);
				
		} else if (workCheck == 4) {

			System.out.println(
					".............................Thank you for visiting us.......................................");

		}

	}

	public static void main(String[] args){
		UsersList usersList = new UsersList();
		
		try {
			usersList.getUserList();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

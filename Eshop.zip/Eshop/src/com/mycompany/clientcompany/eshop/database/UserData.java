package com.mycompany.clientcompany.eshop.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

public class UserData {
	
	//method to fetch all user data and add it in hashMap
	public Map<Integer, Map<String, String>> getUserData() throws SQLException {
		
		Map<Integer, Map<String, String>> allUserData = new LinkedHashMap<>();
		
		Connection connection =null;
		PreparedStatement prepareStatement = null;
		
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/e_shop", "root", "root");
			prepareStatement = connection.prepareStatement("select * from user");
			
			ResultSet allUsers = prepareStatement.executeQuery();
			
			while(allUsers.next()) {
				
				Map<String, String> userData = new LinkedHashMap<>();
				
				int id = allUsers.getInt(1);
				String fName = allUsers.getString(2);
				String lName = allUsers.getString(3);
				String pass= allUsers.getString(4);
				String emailAdd = allUsers.getString(5);
				
				
				userData.put("firstName", fName);
				userData.put("lastName", lName);
				userData.put("password", pass);
				userData.put("email", emailAdd);
				
				allUserData.put(id, userData);
				
				
//				
//				System.out.println("Id: "+ id);
//				System.out.println("firstName: "+ fName);
//				System.out.println("lastName: "+ lName);
//				System.out.println("Password: "+ pass);
//				System.out.println("Email : "+ emailAdd);
//				
//				System.out.println("====================================================================");
//				
			}
		
			
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			connection.close();
			prepareStatement.close();
		}
		
		return allUserData;
		
	}

	public static void main(String[] args) throws SQLException {

		UserData userData = new UserData();
		
		
		Map<Integer, Map<String, String>> allUsersData = userData.getUserData();
		
		System.out.println(allUsersData);
		
	}

}

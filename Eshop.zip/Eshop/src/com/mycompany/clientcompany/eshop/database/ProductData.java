package com.mycompany.clientcompany.eshop.database;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

public class ProductData {
	
	//method to get all product data in one place
	
	public Map<Integer, Map<String, Object>> getAllProducts() throws SQLException {
		
		Map<Integer, Map<String, Object>> allProductsData= new LinkedHashMap<>();
		
		Connection connection= null;
		PreparedStatement prepareStatement = null;
		ResultSet result =null;
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			 connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/e_shop", "root", "root");
			 prepareStatement = connection.prepareStatement("select * from products");
			 
			 result = prepareStatement.executeQuery();
			 
			 while(result.next()) {
				 
				 
				 Map<String, Object> singleProduct= new LinkedHashMap<>();
				 
				 
				 
				 int id = result.getInt(1);
				 
				 String name = result.getString(2);
				 String description = result.getString(3);
				 double price = result.getDouble(4);
				 int quantity = result.getInt(5);
				 
				 singleProduct.put("productName", name);
				 singleProduct.put("productDescription", description);
				 singleProduct.put("productPrice", price);
				 singleProduct.put("producQuantity", quantity);
				 
				 allProductsData.put(id, singleProduct);
				 
			 }
			 
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally {
			connection.close();
			prepareStatement.close();
			result.close();
		}
		
		return allProductsData;
	}

	public static void main(String[] args) throws SQLException {
		ProductData productData = new ProductData();
		
		Map<Integer, Map<String, Object>> allProducts = productData.getAllProducts();
		
		allProducts.forEach((k,v)-> System.out.println(allProducts.get(k)));
		


	}

}









package com.mycompany.clientcompany.eshop.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InsertOrderDatabase {
	
	//method to inserting the order in database
	public boolean insertOrder(Integer customerId, double amount) {
		
		boolean isOrderPlace = false;
		try {
		
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/e_shop", "root", "root");
			
			PreparedStatement prepareStatement = connection.prepareStatement("insert into orders(order_date, amount, customer_id)values(CURRENT_TIMESTAMP, ?, ?)");
			
			prepareStatement.setDouble(1, amount);
			prepareStatement.setInt(2, customerId);
			
			int i = prepareStatement.executeUpdate();
			
			if(i!=0){
				isOrderPlace = true;
			}
			
		
		} catch (ClassNotFoundException e) {

			e.printStackTrace();

		} catch (SQLException e) {

			e.printStackTrace();
			
		}
		
		return isOrderPlace;
		
	}

	public static void main(String[] args) {
//		InsertOrderDatabase insertOrderDatabase = new InsertOrderDatabase();
//		
//		System.out.println(insertOrderDatabase.insertOrder(5, 467.89));

	}

}

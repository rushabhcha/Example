package com.mycompany.clientcompany.eshop.database;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;

import com.mycompany.clientcompany.eshop.admin.QuantityDisplay;
import com.mycompany.clientcompany.eshop.admin.UsersList;
import com.mycompany.clientcompany.eshop.user.inputvalidation.UserInputValidation;

public class OrderData extends UserInputValidation{

	// method to get the order data
	public void getOrdersData(int id) {
		
		boolean isEmpty= true;
		
		Connection connection = null;
		PreparedStatement prepareStatement = null;
		ResultSet resultSet =null;
		
		try {

			Class.forName("com.mysql.cj.jdbc.Driver");

			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/e_shop", "root", "root");

			prepareStatement = connection.prepareStatement(
					"select user.id, concat(user_fname, ' ' , user_lname) as 'full_name', order_date, amount, orders.id from user right join orders on user.id = orders.customer_id where user.id = ? order by order_date desc");

			prepareStatement.setInt(1, id);

			resultSet = prepareStatement.executeQuery();

			int tempNum = 1;
			while (resultSet.next()) {
				
				isEmpty = false;

				int userId = resultSet.getInt(1);
				String fullName = resultSet.getString(2);
				Date orderDate = resultSet.getDate(3);
				Time orderTime = resultSet.getTime(3);
				double orderAmount = resultSet.getDouble(4);
				int orderId = resultSet.getInt(5);

				if (tempNum == 1) {

					System.out.println();
					System.out
							.println("User Id: " + userId + "		User Name: " + fullName);
					System.out.println();
					System.out.println("===============================================================================================================");
					tempNum++;
				}

				System.out.println();
				System.out.println("Order Id: " + orderId + "		Order Date: " + orderDate + "		Order Time : " + orderTime
						+ "		Order Amount: " + orderAmount);

				System.out.println();
				System.out.println("-----------------------------------------------------------------------------------------------------------------");

			}

		} catch (ClassNotFoundException e) {

			e.printStackTrace();

		} catch (SQLException e) {

			e.printStackTrace();

		}finally {
			
			try {
				
				connection.close();
				prepareStatement.close();
				resultSet.close();
				
				
			} catch (SQLException e) {

				e.printStackTrace();
				
			}
		}
		
		if(isEmpty) {
			System.out.println("This user hasn't bought anything yet..................");
			System.out.println();
			System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------");
		}
		
		
		
		//logic to continue admins work
		
		System.out.println("1. to check the quantity of every product press 1");
		System.out.println("2. to check all users list press 2");
		System.out.println("3. to check purches history of user press 3");
		System.out.println("4. to exit press 4");
		System.out.println();
		System.out.println(
				"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

		int workCheck = super.correctInput(4);
		System.out.println();
		if (workCheck == 1) {

			System.out.println();
			// calling the method to calculate the product quantity

			QuantityDisplay quantityDisplay = new QuantityDisplay();

			try {
				
				quantityDisplay.getQuantity();
				
			} catch (SQLException e) {


				e.printStackTrace();
			}

		} else if (workCheck == 2) {
			
			// calling method to get Users List	
			UsersList usersList = new UsersList();
			try {
				
				usersList.getUserList();
				
			} catch (SQLException e) {


				e.printStackTrace();
			}
			System.out.println();
			
		} else if (workCheck == 3) {

			System.out.println();
			
			System.out.println(
					"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

			System.out.println();
			
			int orderCheck = super.correctUserId(10);
			
			System.out.println();
			System.out.println(
					"------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

			System.out.println();
			System.out.println("User Purchase History.........");
			System.out.println();

			//calling method to check history of purchase
			OrderData orderData = new OrderData();
			orderData.getOrdersData(orderCheck);
				
		} else if (workCheck == 4) {

			System.out.println(
					".............................Thank you for visiting us.......................................");

		}

	}

	public static void main(String[] args) {

		OrderData orderData = new OrderData();

		orderData.getOrdersData(2);
	}

}

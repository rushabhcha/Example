package com.wipro.bankofamerica.estore.service;

public interface AccessoriesService {

	public String getSpecificProduct();
}

package com.wipro.bankofamerica.estore.service;
import com.wipro.bankofamerica.estore.model.Address;
/**
*
* @author Jeevan
*/
public interface AddressService {
	
	public Address saveAddress(Address address);
	
}
